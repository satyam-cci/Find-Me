//
//  BookResponse.h
//  Find-Me
//
//  Created by Satyam Raikar on 25/10/13.
//  Copyright (c) 2013 CCI. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BookResponse : NSObject
@property (copy) NSString *bookResponse;
@end
