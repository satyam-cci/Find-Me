//
//  Common.h
//  Find-Me
//
//  Created by Callista Dsouza on 25/10/13.
//  Copyright (c) 2013 CCI. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Common : NSObject


- (NSString *)getMacAddress:(NSString *)type;


@end
