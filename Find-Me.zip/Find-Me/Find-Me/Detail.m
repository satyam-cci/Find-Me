//
//  Detail.m
//  Find-Me
//
//  Created by Ankita Kalangutkar on 25/10/13.
//  Copyright (c) 2013 CCI. All rights reserved.
//

#import "Detail.h"

@implementation Detail
-(id) init
{
    if (self == [super self]) {
        
    }
    return self;
}

@end
