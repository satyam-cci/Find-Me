//
//  BookResponse.m
//  Find-Me
//
//  Created by Satyam Raikar on 25/10/13.
//  Copyright (c) 2013 CCI. All rights reserved.
//

#import "BookResponse.h"

@implementation BookResponse

-(id) init
{
	if (self == [super init]) {
		
	}
	return self;
}
@end
