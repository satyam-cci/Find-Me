//
//  Detail.h
//  Find-Me
//
//  Created by Ankita Kalangutkar on 25/10/13.
//  Copyright (c) 2013 CCI. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Detail : NSObject
@property (copy) NSString * deviceID;
@property (copy) NSString * emp_name;
@property (copy) NSString * status;
@property (copy) NSString * deviceName;
@property (copy) NSString * bookedEmpName;
@end
